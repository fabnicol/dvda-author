char *readconfentry(const char *s);
