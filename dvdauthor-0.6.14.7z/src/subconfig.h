/* Common data directory (for fonts, etc) */
#define TEXTSUB_DATADIR "../font/"
