/* @(#)version.h	1.55 10/06/02 Copyright 2007-2010 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION	"3.00"
