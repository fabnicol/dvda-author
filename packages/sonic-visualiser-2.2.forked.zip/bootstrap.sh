#!/bin/sh
aclocal -I . && autoconf 
