/* These stubs are provided so that autoconf can check library
 * versions using C symbols only */

extern void dataquay_v_0_9_present(void) { }
