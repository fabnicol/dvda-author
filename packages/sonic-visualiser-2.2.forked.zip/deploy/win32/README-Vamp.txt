
To add Vamp audio analysis plugins to the Transform menu in
Sonic Visualiser, unpack them into this directory.

See http://vamp-plugins.org/ for more information.
